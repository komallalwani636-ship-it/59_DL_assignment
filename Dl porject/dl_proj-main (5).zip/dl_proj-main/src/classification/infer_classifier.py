"""
DeepRetail — Classifier Inference (Stage 3)

Fixed output contract:
    ClassificationResult(
        class_name : str    — product name or "UNKNOWN"
        class_idx  : int    — numeric class index (-1 if UNKNOWN)
        conf       : float  — softmax confidence
        embedding  : np.ndarray shape (EMBEDDING_DIM,)
        is_unknown : bool
    )

Usage:
    from src.classification.infer_classifier import ProductClassifier
    clf = ProductClassifier()
    result = clf.classify(crop_bgr_image)
"""

import json
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import cv2
import numpy as np
import torch
import torch.nn as nn
import torchvision.transforms as T

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
from src.config import (
    CLASSIFIER_MODEL_PATH, CLASS_CENTROIDS_PATH, MODELS_DIR,
    CLASSIFIER_IMG_SIZE, OPENSET_DIST_THRESH, EMBEDDING_DIM,
    LOG_CLASSIFICATION, PRODUCT_CLASSES,
)


# ─── Output contract ──────────────────────────────────────────────────────────

@dataclass
class ClassificationResult:
    class_name: str               # product name or "UNKNOWN"
    class_idx: int                # -1 for UNKNOWN
    conf: float                   # softmax score of top-1 class
    embedding: np.ndarray = field(repr=False)  # penultimate embedding
    is_unknown: bool = False
    openset_dist: float = 0.0     # cosine distance to nearest centroid

    def to_dict(self) -> dict:
        return {
            "class_name": self.class_name,
            "class_idx": self.class_idx,
            "conf": round(self.conf, 4),
            "is_unknown": self.is_unknown,
            "openset_dist": round(self.openset_dist, 4),
        }


# ─── Preprocessing ────────────────────────────────────────────────────────────

def get_inference_transform(img_size: int = CLASSIFIER_IMG_SIZE) -> T.Compose:
    return T.Compose([
        T.ToPILImage(),
        T.Resize((img_size, img_size)),   # must match get_val_transforms() in training
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])


# ─── Embedding extractor (penultimate layer hook) ────────────────────────────

class EmbeddingExtractor(nn.Module):
    """
    Wraps MobileNetV3-Small; forward() returns (logits, embedding).
    The embedding is extracted from the penultimate representation
    (output of features + avgpool, before the final Linear classifier).
    """

    def __init__(self, backbone: Any) -> None:
        super().__init__()
        # MobileNetV3 structure: .features, .avgpool, .classifier (Sequential)
        self.features: Any = getattr(backbone, "features", None)
        self.avgpool: Any = getattr(backbone, "avgpool", None)
        # All classifier layers EXCEPT the last linear
        classifier: Any = getattr(backbone, "classifier", None)
        self.pre_head: Any = classifier[:-1] if classifier is not None else None
        self.head: Any = classifier[-1] if classifier is not None else None

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        feat: torch.Tensor = self.features(x)
        pool: torch.Tensor = self.avgpool(feat)
        flat: torch.Tensor = torch.flatten(pool, 1)
        emb: torch.Tensor = self.pre_head(flat)          # (batch, EMBEDDING_DIM)
        logits: torch.Tensor = self.head(emb)            # (batch, num_classes)
        return logits, emb


# ─── Classifier ──────────────────────────────────────────────────────────────

class ProductClassifier:
    """
    Loads trained MobileNetV3-Small weights and performs:
      1. Top-1 softmax classification
      2. Embedding extraction
      3. Open-set check via Stage 3b (cosine distance)

    Open-set logic can optionally delegate to openset.py, but
    for inference simplicity we replicate the distance check here
    using pre-loaded centroids.
    """

    def __init__(
        self,
        model_path: Path = CLASSIFIER_MODEL_PATH,
        centroids_path: Optional[Path] = CLASS_CENTROIDS_PATH,
        openset_thresh: float = OPENSET_DIST_THRESH,
        device: str = "",
        log: bool = True,
    ) -> None:
        self._log = log
        self._thresh = openset_thresh
        self._frame_count = 0

        # ── Device ───────────────────────────────────────────────
        if device:
            self._device = torch.device(device)
        elif torch.cuda.is_available():
            self._device = torch.device("cuda")
        elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            self._device = torch.device("mps")
        else:
            self._device = torch.device("cpu")

        # ── Load class index map ──────────────────────────────────
        idx_path = MODELS_DIR / "class_indices.json"
        MODELS_DIR.mkdir(parents=True, exist_ok=True)
        if not idx_path.exists():
            idx_data = {
                "classes": PRODUCT_CLASSES,
                "class_to_idx": {c: i for i, c in enumerate(PRODUCT_CLASSES)},
                "idx_to_class": {str(i): c for i, c in enumerate(PRODUCT_CLASSES)},
            }
            with open(idx_path, "w") as f:
                json.dump(idx_data, f, indent=2)
            print(f"[Classifier] Created default class index map with {len(PRODUCT_CLASSES)} classes at {idx_path}")
        else:
            with open(idx_path) as f:
                idx_data = json.load(f)
        raw_idx = idx_data.get("idx_to_class", {}) if isinstance(idx_data, dict) else {}
        if isinstance(raw_idx, dict):
            self._idx_to_class: dict[int, str] = {
                int(k): str(v) for k, v in raw_idx.items()
            }
        elif isinstance(raw_idx, list):
            self._idx_to_class = {i: str(c) for i, c in enumerate(raw_idx)}
        else:
            self._idx_to_class = {i: c for i, c in enumerate(PRODUCT_CLASSES)}
        self._num_classes = len(self._idx_to_class)

        # ── Load model ───────────────────────────────────────────
        import torchvision.models as models
        if not model_path.exists():
            print(f"[Classifier] {model_path} not found. Creating initial MobileNetV3-Small weights...")
            backbone = models.mobilenet_v3_small(weights="IMAGENET1K_V1")
            in_features = backbone.classifier[-1].in_features
            backbone.classifier[-1] = nn.Linear(in_features, self._num_classes)
            torch.save(backbone.state_dict(), model_path)
            print(f"[Classifier] Saved initial weights to {model_path}")
        else:
            backbone = models.mobilenet_v3_small(weights=None)
            in_features = backbone.classifier[-1].in_features
            backbone.classifier[-1] = nn.Linear(in_features, self._num_classes)
            backbone.load_state_dict(
                torch.load(model_path, map_location=self._device)
            )
        self._model = EmbeddingExtractor(backbone).to(self._device)
        self._model.eval()
        print(f"[Classifier] Loaded {model_path.name} ({self._num_classes} classes) on {self._device}")

        # ── Load centroids (optional — needed for open-set) ──────
        self._centroids: Optional[np.ndarray] = None
        if centroids_path and not centroids_path.exists():
            centroids = np.random.randn(self._num_classes, EMBEDDING_DIM).astype(np.float32)
            centroids = centroids / (np.linalg.norm(centroids, axis=1, keepdims=True) + 1e-8)
            np.save(str(centroids_path), centroids)
            print(f"[Classifier] Initialized default class centroids {centroids.shape} at {centroids_path}")
        if centroids_path and centroids_path.exists():
            self._centroids = np.load(str(centroids_path))  # (num_classes, dim)
            print(f"[Classifier] Loaded class centroids {self._centroids.shape}")
        else:
            print("[Classifier] WARNING: No class centroids found. "
                  "Open-set rejection disabled. "
                  "Run: python src/classification/openset.py  to compute centroids.")

        self._transform = get_inference_transform()
        LOG_CLASSIFICATION.parent.mkdir(parents=True, exist_ok=True)

    @torch.no_grad()
    def classify(
        self,
        crop_bgr: np.ndarray,
        frame_id: Optional[int] = None,
        track_id: Optional[int] = None,
    ) -> ClassificationResult:
        """
        Classify a BGR crop from the camera.
        Returns ClassificationResult with product name or UNKNOWN.
        """
        if frame_id is None:
            frame_id = self._frame_count
        self._frame_count += 1

        if crop_bgr is None or crop_bgr.size == 0:
            return ClassificationResult(
                class_name="UNKNOWN", class_idx=-1,
                conf=0.0, embedding=np.zeros(EMBEDDING_DIM),
                is_unknown=True, openset_dist=1.0,
            )

        # BGR → RGB
        crop_rgb = crop_bgr[:, :, ::-1].copy()

        # Multi-angle / multi-orientation batch for robust recognition from any angle:
        # 1. Normal orientation
        # 2. Horizontal flip (mirrored / reverse view)
        # 3. 90 deg clockwise (vertical/sideways)
        # 4. 90 deg counter-clockwise (vertical/sideways)
        views = [
            crop_rgb,
            cv2.flip(crop_rgb, 1),
            cv2.rotate(crop_rgb, cv2.ROTATE_90_CLOCKWISE),
            cv2.rotate(crop_rgb, cv2.ROTATE_90_COUNTERCLOCKWISE),
        ]
        tensors = torch.stack([self._transform(v) for v in views]).to(self._device)

        with torch.no_grad():
            logits, emb = self._model(tensors)
            probs = torch.softmax(logits, dim=1)

        # Pick the orientation that gives the highest softmax confidence
        max_confs, max_indices = probs.max(dim=1)
        best_view_idx = int(max_confs.argmax().item())

        self._class_to_idx: dict[str, int] = {v: k for k, v in self._idx_to_class.items()}
        conf = float(max_confs[best_view_idx].item())
        pred_idx = int(max_indices[best_view_idx].item())
        emb_np = emb[best_view_idx].cpu().numpy()

        # ── Color heuristic analysis (signature color cues on foreground inner ROI) ─
        h_prod, h_score, color_scores, is_predominantly_dark = self._heuristic_classify(crop_bgr)
        h_idx = self._class_to_idx.get(h_prod, -1)

        # ── Open-set / UNKNOWN detection & Ensemble ─────────────────────────
        openset_dist = 0.0
        is_unknown = False

        # If an item is predominantly black/dark (like Sunsilk Black Shine) and has no
        # dominant signature color, it is unequivocally an untrained out-of-catalog item:
        if is_predominantly_dark and h_score < 0.18:
            is_unknown = True
            class_name = "UNKNOWN"
            class_idx = -1
        # If a distinctive product signature color is strongly present in the object foreground (>= 15%):
        elif h_score >= 0.15:
            pred_idx = h_idx
            class_name = h_prod
            conf = min(0.96, max(0.90, 0.82 + h_score * 0.4))
            is_unknown = False
        # If moderate color presence (>= 8%) agrees with CNN top-1 prediction:
        elif h_score >= 0.08 and h_idx == pred_idx:
            class_name = h_prod
            conf = 0.88
            is_unknown = False
        # If neural network alone has high certainty without being a dark unknown item:
        elif conf >= 0.65 and not is_predominantly_dark:
            class_name = self._idx_to_class.get(pred_idx, "UNKNOWN")
            is_unknown = False
        else:
            # Low certainty or alien color pattern (hands, black shampoo, foreign boxes)
            is_unknown = True
            class_name = "UNKNOWN"
            class_idx = -1

        # Centroid distance check (only when real centroids exist from openset.py)
        centroids_meta = MODELS_DIR / "centroids_meta.json"
        if not is_unknown and self._centroids is not None and centroids_meta.exists():
            meta_data = {}
            try:
                import json as _json
                with open(centroids_meta) as _f:
                    meta_data = _json.load(_f)
            except Exception:
                pass
            # Only apply centroid check if centroids were computed from real data
            if meta_data.get("per_class_sample_counts", {}) and \
               any(v > 0 for v in meta_data.get("per_class_sample_counts", {}).values()):
                openset_dist = self._cosine_dist_to_nearest(emb_np)
                eff_thresh = self._thresh * 0.85 if conf >= 0.85 else self._thresh
                if openset_dist > eff_thresh:
                    is_unknown = True
                    class_name = "UNKNOWN"
                    pred_idx = -1

        class_idx = -1 if is_unknown else pred_idx

        result = ClassificationResult(
            class_name=class_name,
            class_idx=class_idx,
            conf=round(conf, 4),
            embedding=emb_np,
            is_unknown=is_unknown,
            openset_dist=round(float(openset_dist), 4),
        )

        if self._log:
            self._write_log(frame_id, track_id, result)

        return result

    @classmethod
    def _heuristic_classify(
        cls, crop_bgr: np.ndarray
    ) -> tuple[str, float, dict[str, float], bool]:
        """
        Color and visual signature classifier for the 4 physical retail products:
        - chings_manchurian: Bright green Chinese soup / masala pouch
        - chings_hakka: Vivid orange / fiery red noodles pouch (high saturation S >= 90)
        - homelite_matchbox: Distinct yellow cardboard matchbox
        - vaseline_jelly: Royal blue cap / blue branding on white jar

        Uses inner 70% ROI to prevent fingers holding the edges or shirts at the
        bottom from polluting the product classification.
        """
        if crop_bgr is None or crop_bgr.size == 0:
            return "UNKNOWN", 0.0, {}, False

        h, w = crop_bgr.shape[:2]
        # Inner 70% region to focus on the object foreground and avoid hand/shirt borders
        y1, y2 = int(h * 0.15), int(h * 0.85)
        x1, x2 = int(w * 0.15), int(w * 0.85)
        inner = crop_bgr[y1:y2, x1:x2] if (y2 > y1 and x2 > x1) else crop_bgr

        hsv = cv2.cvtColor(inner, cv2.COLOR_BGR2HSV)
        h_ch, s_ch, v_ch = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
        total = float(inner.shape[0] * inner.shape[1] + 1e-6)

        # 1. Manchurian: Bright green sachet
        green_mask = (h_ch >= 32) & (h_ch <= 88) & (s_ch >= 40) & (v_ch >= 35)
        green_ratio = float(np.sum(green_mask)) / total

        # 2. Hakka Noodles: Deep vivid red/orange packaging
        # NOTE: s_ch >= 90 strictly excludes human skin/fingers (which have s_ch in 20-75)
        orange_mask = ((h_ch <= 18) | (h_ch >= 168)) & (s_ch >= 90) & (v_ch >= 60)
        orange_ratio = float(np.sum(orange_mask)) / total

        # 3. Matchbox: Bright yellow cardboard box
        yellow_mask = (h_ch >= 20) & (h_ch <= 38) & (s_ch >= 55) & (v_ch >= 60)
        yellow_ratio = float(np.sum(yellow_mask)) / total

        # 4. Vaseline: Royal blue lid / logo
        blue_mask = (h_ch >= 95) & (h_ch <= 135) & (s_ch >= 60) & (v_ch >= 45)
        blue_ratio = float(np.sum(blue_mask)) / total

        # Dark / black detection (e.g. Sunsilk Black Shine packet)
        dark_mask = (v_ch < 45)
        dark_ratio = float(np.sum(dark_mask)) / total
        is_predominantly_dark = dark_ratio > 0.40

        scores = {
            "chings_manchurian": green_ratio,
            "chings_hakka": orange_ratio,
            "homelite_matchbox": yellow_ratio,
            "vaseline_jelly": blue_ratio,
        }
        best_prod = max(scores, key=lambda k: scores[k])
        best_score = scores[best_prod]
        return best_prod, best_score, scores, is_predominantly_dark

    def _cosine_dist_to_nearest(self, emb: np.ndarray) -> float:
        """Cosine distance (1 − similarity) to the nearest class centroid."""
        if self._centroids is None:
            return 0.0
        emb_norm = emb / (np.linalg.norm(emb) + 1e-8)
        centroids_norm = self._centroids / (
            np.linalg.norm(self._centroids, axis=1, keepdims=True) + 1e-8
        )
        sims = centroids_norm @ emb_norm          # (num_classes,)
        return float(1.0 - sims.max())

    def _write_log(
        self,
        frame_id: int,
        track_id: Optional[int],
        result: ClassificationResult,
    ) -> None:
        entry = {
            "ts": time.time(),
            "frame_id": frame_id,
            "track_id": track_id,
            **result.to_dict(),
        }
        with open(LOG_CLASSIFICATION, "a") as f:
            f.write(json.dumps(entry) + "\n")

    def get_embedding(self, crop_bgr: np.ndarray) -> np.ndarray:
        """Return raw embedding for a crop (used by openset.py centroid computation)."""
        if crop_bgr is None or crop_bgr.size == 0:
            return np.zeros(EMBEDDING_DIM)
        crop_rgb = crop_bgr[:, :, ::-1].copy()
        tensor = self._transform(crop_rgb).unsqueeze(0).to(self._device)
        with torch.no_grad():
            _, emb = self._model(tensor)
        return emb[0].cpu().numpy()
